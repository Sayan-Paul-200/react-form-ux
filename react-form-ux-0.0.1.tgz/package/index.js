// Placeholder package
module.exports = {}