# react-form-ux

UX helpers for React forms.

Features:

- Focus first invalid field
- Scroll to first error
- Accessible error summaries

Work in progress.